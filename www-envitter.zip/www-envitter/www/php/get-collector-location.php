<?php
include '../connect.php';
$value = json_decode(file_get_contents('php://input'));
echo $db->collector_location->find(array("date"=>date('Y-m-d'), "collector_name"=>$value->{"collector_name"}))->count();
if($db->collector_location->find(array("date"=>date('Y-m-d'), "collector_name"=>$value->{"collector_name"}))->count() == 0){
    $details = array(
        "collector_name" => $value->{"collector_name"},
        "latitude" => array($value->{"lat"}),
        "longitude" => array($value->{"lng"}),
        "time" => array($value->{"time"}),
        "date" => date('Y-m-d')
    );
    $db->collector_location->insert($details);
}
else{
    $details_lat = array(
        '$push' => array("latitude" => $value->{"lat"})
    );
    $details_lng = array(
        '$push' => array("longitude" => $value->{"lng"})
    );
    $details_time = array(
        '$push' => array("time" => $value->{"time"})
    );
    $db->collector_location->update(array("collector_name"=>$value->{"collector_name"}), $details_lat);
    $db->collector_location->update(array("collector_name"=>$value->{"collector_name"}), $details_lng);
    $db->collector_location->update(array("collector_name"=>$value->{"collector_name"}), $details_time);
}

?>
