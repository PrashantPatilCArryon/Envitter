<?php
include '../connect.php';
$collector = $_POST['collector-name'];
$date = $_POST['collection-date'];

foreach ($_POST['chk'] as $value) {
    $db->donors->update(array(
       "_id"=>new MongoId($value)),
       array(
           '$set' => array(
               //"status"=>"1",
               "collector_name"=>$collector,
           )
       )
   );
   $db->donors->update(array(
      "_id"=>new MongoId($value)),
      array(
          '$push' => array('visit_date' => $date)
      )
  );
}
header('Location:../generate-visit-list.php');
?>
