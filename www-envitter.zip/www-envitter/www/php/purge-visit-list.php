<?php
include '../connect.php';
foreach($_POST['chk'] as $value){
   $db->donors->update(array(
       "_id"=>new MongoId($value)),
       array(
           '$set'=>array(
               //"status"=>"0",
               "collector-name"=>""
           )
       )
   );
}
header('Location:../visit-listings.php');
?>
