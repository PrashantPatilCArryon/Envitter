<?php
include '../connect.php';
if(isset($_GET['_id'])){
    $details = array(
        "name"=>$_POST["name"],
        "flat_no"=>$_POST['flat_no'],
        "building"=>$_POST['building'],
        "address"=>$_POST["address"],
        "latitude"=>$_POST["latitude"],
        "longitude"=>$_POST["longitude"],
        "contact"=>$_POST["contact"],
        "location"=>$_POST["location"]
    );
   $db->donors->update(array("_id"=>new MongoId($_GET['_id'])), array('$set'=>$details));
}
else{
   $details = array(
       "name"=>$_POST["name"],
       "flat_no"=>$_POST['flat_no'],
       "building"=>$_POST['building'],
       "address"=>$_POST["address"],
       "latitude"=>$_POST["latitude"],
       "longitude"=>$_POST["longitude"],
       "contact"=>$_POST["contact"],
       "status"=>"0",
       "location"=>$_POST["location"]
   );
   $db->donors->insert($details);
}
header('Location:../donor-listings.php');
?>
