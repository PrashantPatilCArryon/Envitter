<?php
include '../connect.php';
$details = array("name"=>$_POST["name"], "address"=>$_POST["address"], "contact"=>$_POST["contact"], "email"=>$_POST["email"]);
$db->volunteers->insert($details);

header('Location:../volunteer-listings.php');
?>
