$(document).ready(function() {
   $('#donors').DataTable();
   $('#collectors').DataTable();
   $('#collection_list').DataTable();
   $("#select-all").change(function(){
      $(".checkbox").prop('checked', $(this).prop("checked"));
   });
});

function toggle(source) {
   checkboxes = document.getElementsByName('chk[]');
   for(var i = 0, n = checkboxes.length; i < n; i++) {
      checkboxes[i].checked = source.checked;
   }
}

function deleteMultiEntry(dbName) {
   var val = [];
   $(':checkbox:checked').each(function(i) {
      val[i] = $(this).val();
   });
   if(val == '') {
      alert('Please select rows to delete!');
      return false;
   }
   var dataString = 'id=' + val + '&dbName=' + dbName;
   console.log(dataString);
   var answer = confirm ("Are you sure?")
   if (answer) {
      $.ajax({
         url: "php/delete-multiple-entries.php",
         type: "POST",
         data: dataString,
         cache: false,
         success: function (html) {
            if (html == '') {
               alert("Please try again!");
            }
            else {
               location.reload();
            }
         }
      });
   }
   else {

   }
}
