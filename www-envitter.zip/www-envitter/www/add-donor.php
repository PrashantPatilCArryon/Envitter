<?php
   include 'header.php';
   ?>

      <div class="app-container">
         <div class="row content-container">

            <!-- Main Content -->
            <div class="container-fluid">
               <div class="side-body padding-top">
                  <h2 style="margin-bottom: 20px;">Add a new Donor</h2>
                  <div class="col-lg-6">
                     <input id="pac-input" class="controls" type="text" placeholder="Search Box">
                     <div id="map"></div>
                  </div>
               </div>
            </div>
         </div>
         <footer class="app-footer">
            <div class="wrapper">
               &copy; 2016 @ Danish, Sagar, Siddhant
            </div>
         </footer>
      </div>
