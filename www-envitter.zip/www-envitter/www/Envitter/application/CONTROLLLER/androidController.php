<?php

class androidController extends CI_Controller {
  public function index()
  {

  }
  public function insertDescriptionController(){
    $this->load->model('androidModel');
    $postdata=file_get_contents("php://input");
   $decodedobj=json_decode($postdata);
  /*  $data = base64_decode($decodedobj->img);
    $im = imagecreatefromstring($data);
    file_put_contents('img/abc.jpg', $im);*/

    // Get image string posted from Android App
   $base=$decodedobj->img;
   // Get file name posted from Android App
   $filename = $this->androidModel->getidissues();
   $filename=(string)$filename;
   $jpeg=".jpeg";
   $filename=$filename.$jpeg;
   // Decode Image
   $binary=base64_decode(urldecode($base));
   header('Content-Type: bitmap; charset=utf-8');
   // Images will be saved under 'www/imgupload/uplodedimages' folder
   $file = fopen('C:/wamp/www/imgupload/uploadedimages'.$filename, 'w');
   // Create File
   fwrite($file, $binary);
   fclose($file);
   echo 'Image upload complete, Please check your php file directory';
   $imgurl="192.168.100.88/imgupload/uploadedimages".$filename;

    $cat_id=$decodedobj->catid;
    $lat=$decodedobj->lat;
    $long=$decodedobj->longi;
    $desc=$decodedobj->desc;
  /*  $dateTime=new DateTime("now",new DateTimeZone('Asia/Kolkata'))
    $date1 = $dateTime->format('Y-m-d');
    print_r($date1);*/
    $this->androidModel->insertDescription($cat_id,$lat,$long,$desc,$imgurl);
  }

  public function getlistController(){

    $this->load->model('androidModel');
    $data['recordslist']=$this->androidModel->getlistModel();
    print_r(json_encode($data));
  }

  public function agg_countincrement(){
      $this->load->model('androidModel');
      $postdata=file_get_contents("php://input");
      $decodedobj=json_decode($postdata);
  }



}

 ?>
