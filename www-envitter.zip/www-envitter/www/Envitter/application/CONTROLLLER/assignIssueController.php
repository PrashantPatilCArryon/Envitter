<?php

class assignIssueController extends CI_Controller {
  public function index()
  {
  }
  public function getPerson()
  {
    

  }

  public function putPerson()
  {


  }

}

 ?>
