<?php

echo 'Hello';

foreach($records as $rec){
  echo $rec->id." ".$rec->name;

}

 ?>
